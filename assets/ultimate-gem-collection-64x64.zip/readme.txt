
Thank you for downloading this pack!

Full resolution (768x768) version available here: https://magory.itch.io/ultimate-gem-collections

You can use those gems in any free or commercial project of yours.

Check out my other assets and games at magory.itch.io.

Check out my music on Spotify and streaming services - search for Tomasz Kucza
